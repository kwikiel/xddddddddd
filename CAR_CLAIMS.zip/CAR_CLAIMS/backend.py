from fastapi import FastAPI, Request, Form
from fastapi.responses import HTMLResponse
from fastapi.templating import Jinja2Templates
from typing import Optional
from chatbot_api import query_ollama
import requests
import logging

# Configure logging
logging.basicConfig(level=logging.INFO, 
                    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

app = FastAPI()
templates = Jinja2Templates(directory="templates")

# System prompt to guide the model's behavior
SYSTEM_PROMPT = """You are an insurance claims assistant for Efficient Insurance Solutions. 
You help customers with their car insurance claims.
Be professional, helpful, and concise in your responses.
Always maintain a friendly tone and offer solutions whenever possible."""

@app.get("/", response_class=HTMLResponse)
async def root(request: Request):
    return templates.TemplateResponse("form.html", {"request": request})

@app.post("/submit", response_class=HTMLResponse)
async def submit_form(request: Request, name: str = Form(...)):
    # Use the LLM API to generate a response
    user_message = name
    # Using the model that's available in the local server
    model_name = "deepseek-r1-distill-llama-8b"
    
    logger.info(f"Processing user message: {user_message}")
    
    try:
        # Get response from the LLM API
        bot_response = query_ollama(
            model_name=model_name,
            prompt=user_message,
            system_prompt=SYSTEM_PROMPT,
            temperature=0.7
        )
        
        logger.info(f"Received raw response from LLM: {bot_response[:100]}...")
        
        # Check if the response contains an error message or is empty
        if bot_response.startswith("Error querying LLM API"):
            logger.error(f"API error: {bot_response}")
            bot_response = "I'm sorry, but I'm having trouble connecting to my AI service at the moment. Please try again later or contact our support team for immediate assistance."
        elif bot_response == "No response generated" or not bot_response.strip():
            logger.warning("Empty or null response received from API")
            bot_response = "I apologize, but I couldn't generate a proper response to your query. This might be due to the model being unavailable or still loading. Please try a different question or contact our support team."
    except Exception as e:
        # Handle any unexpected errors
        logger.exception(f"Unexpected error: {str(e)}")
        bot_response = "I apologize, but I encountered an issue while processing your request. Please try again or contact our support team for assistance."
    
    return templates.TemplateResponse("response.html", {
        "request": request,
        "name": user_message,
        "response": bot_response
    })