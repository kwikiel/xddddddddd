from fastapi import FastAPI, Request, Form
from fastapi.responses import HTMLResponse
from fastapi.templating import Jinja2Templates
from typing import Optional
from chatbot_api import query_ollama

app = FastAPI()
templates = Jinja2Templates(directory="templates")

# System prompt to guide the model's behavior
SYSTEM_PROMPT = """You are an insurance claims assistant for Efficient Insurance Solutions. 
You help customers with their car insurance claims.
Be professional, helpful, and concise in your responses.
Always maintain a friendly tone and offer solutions whenever possible."""

@app.get("/", response_class=HTMLResponse)
async def root(request: Request):
    return templates.TemplateResponse("form.html", {"request": request})

@app.post("/submit", response_class=HTMLResponse)
async def submit_form(request: Request, name: str = Form(...)):
    # Use the Ollama API to generate a response
    user_message = name
    model_name = "llama3.1"  # Using the Llama 3.1 model
    
    # Get response from the LLM via Ollama API
    bot_response = query_ollama(
        model_name=model_name,
        prompt=user_message,
        system_prompt=SYSTEM_PROMPT,
        temperature=0.7
    )
    
    return templates.TemplateResponse("response.html", {
        "request": request,
        "name": user_message,
        "response": bot_response
    })