import requests
import json

def query_ollama(model_name, prompt, system_prompt=None, temperature=0.7):
    """
    Send a request to the Ollama API endpoint.

    Args:
        model_name (str): The name of the model to use (e.g., 'llama2', 'mistral', 'gemma')
        prompt (str): The user's prompt/query
        system_prompt (str, optional): System instructions for the model
        temperature (float, optional): Controls randomness in generation (0.0-1.0)

    Returns:
        str: The model's response text
    """
    url = "http://ollama.k8s-tesla.eisolutions.eu//api/generate"

    payload = {
        "model": model_name,
        "prompt": prompt,
        "temperature": temperature,
        "stream": False
    }

    # Add system prompt if provided
    if system_prompt:
        payload["system"] = system_prompt

    try:
        response = requests.post(url, json=payload)
        response.raise_for_status()  # Raise exception for HTTP errors

        result = response.json()
        return result.get("response", "No response generated")

    except requests.exceptions.RequestException as e:
        return f"Error querying Ollama API: {str(e)}"

# Example usage
if __name__ == "__main__":
    model = "llama3.1"
    prompt = "Explain how gradient boosting works in machine learning"

    response = query_ollama(model, prompt)
    print(response)