import requests
import json

def query_ollama(model_name, prompt, system_prompt=None, temperature=0.7):
    """
    Send a request to the local LLM service using OpenAI-compatible chat completions API.

    Args:
        model_name (str): The name of the model to use (e.g., 'deepseek-r1-distill-llama-8b')
        prompt (str): The user's prompt/query
        system_prompt (str, optional): System instructions for the model
        temperature (float, optional): Controls randomness in generation (0.0-1.0)

    Returns:
        str: The model's response text
    """
    url = "http://localhost:1234/v1/chat/completions"

    # Prepare messages in chat format
    messages = []
    if system_prompt:
        messages.append({"role": "system", "content": system_prompt})
    
    # Add user message
    messages.append({"role": "user", "content": prompt})

    payload = {
        "model": model_name,
        "messages": messages,
        "temperature": temperature,
        "max_tokens": -1,
        "stream": False
    }

    try:
        print(f"Sending request to {url} with payload: {json.dumps(payload, indent=2)}")
        response = requests.post(url, json=payload)
        response.raise_for_status()  # Raise exception for HTTP errors

        result = response.json()
        print(f"Received response: {json.dumps(result, indent=2)}")
        
        # Extract the content from the ChatCompletion response format
        if result and "choices" in result and len(result["choices"]) > 0:
            return result["choices"][0]["message"]["content"]
        else:
            return "No response generated"

    except requests.exceptions.RequestException as e:
        error_msg = f"Error querying LLM API: {str(e)}"
        print(error_msg)
        if hasattr(e, 'response') and e.response is not None:
            print(f"Response status: {e.response.status_code}")
            print(f"Response body: {e.response.text}")
        return error_msg

# Example usage
if __name__ == "__main__":
    model = "deepseek-r1-distill-llama-8b"
    prompt = "Explain how gradient boosting works in machine learning"
    system = "You are a helpful and knowledgeable assistant."

    response = query_ollama(model, prompt, system)
    print("Final response:", response)